{{- define  "pega.installer" -}}
{{- $arg := .action -}}
kind: Job
apiVersion: batch/v1
metadata:
  name: {{ .name }}
  namespace: {{ .root.Release.Namespace }}
  annotations:
{{- if  (eq .root.Values.waitForJobCompletion "true")   }}
    "helm.sh/hook-weight": "0"
    "helm.sh/hook-delete-policy": {{ if .root.Values.cleanAfterInstall -}} before-hook-creation,hook-succeeded {{- else -}} before-hook-creation {{- end }}
{{- if  (eq .root.Values.global.actions.execute "install") }}
    # Forces Helm to wait for the install to complete.
    "helm.sh/hook": post-install
{{- end }}
{{- if (eq .root.Values.global.actions.execute "upgrade") }}
    # Forces Helm to wait for the upgrade to complete.
    "helm.sh/hook": post-install, post-upgrade
{{- end }}
{{- end }}
{{- if .root.Values.global.pegaJob }}{{- if .root.Values.global.pegaJob.annotations }}
{{ toYaml .root.Values.global.pegaJob.annotations | indent 4 }}
{{- end }}{{- end }}
  labels:
    app: {{ .name }}
    {{ include "generatedInstallerJobLabels" .root | indent 4 }}
spec:
  backoffLimit: 0
  template:
    metadata:
      labels:
        app: "installer"
        installer-job: {{ .name }}
        {{- if .root.Values.podLabels }}
{{ toYaml .root.Values.podLabels | indent 8 }}
        {{- end -}}
{{ include "generatedInstallerPodLabels" .root | indent 8 }}
      annotations:
{{- if .root.Values.podAnnotations}}
{{ toYaml .root.Values.podAnnotations | indent 8 }}
{{- end }}
    spec:
      shareProcessNamespace: {{ .root.Values.shareProcessNamespace }}
{{- if .root.Values.serviceAccountName }}
      serviceAccountName: {{ .root.Values.serviceAccountName }}
{{- end }}
      volumes:
{{- include "jdbcLibVolume" .root | indent 6 }}
{{- include "downloadScriptVolume" (merge .root (dict "chartType" "installer")) | indent 6 }}
{{- include "kitVolume" .root | indent 6 }}
{{- include "kitDownloadScriptVolume" .root | indent 6 }}
{{- if .root.Values.installerMountVolumeClaimName }}
      - name: {{ template "pegaInstallerMountVolume" }}
        persistentVolumeClaim:
          claimName: {{ .root.Values.installerMountVolumeClaimName }}
{{- end }}
{{- if .root.Values.custom }}{{- if .root.Values.custom.volumes }}
{{ toYaml .root.Values.custom.volumes | indent 6 }}
{{- end }}{{- end }}
      - name: {{ template "pegaInstallerCredentialsVolume" }}
        projected:
          defaultMode: 420
          sources:
          {{- $d := dict "deploySecret" "deployDBSecret" "deployNonExtsecret" "deployNonExtDBSecret" "extSecretName" .root.Values.global.jdbc.external_secret_name "nonExtSecretName" "pega-db-secret-name" "context" .root  -}}
          {{ include "secretResolver" $d | indent 10}}

          {{- $artifactoryDict := dict "deploySecret" "deployArtifactorySecret" "deployNonExtsecret" "deployNonExtArtifactorySecret" "extSecretName" .root.Values.global.customArtifactory.authentication.external_secret_name "nonExtSecretName" "pega-custom-artifactory-secret-name" "context" .root -}}
          {{ include "secretResolver" $artifactoryDict | indent 10}}

          {{- $extRestSecretName := "" }}
          {{- if .root.Values.upgrade }}{{- if .root.Values.upgrade.pega_rest_external_secret_name }}{{- $extRestSecretName = .root.Values.upgrade.pega_rest_external_secret_name }}{{- end }}{{- end }}
          {{- $pegaRestDict := dict "deploySecret" "deployPegaRESTSecret" "deployNonExtsecret" "deployNonExtPegaRESTSecret" "extSecretName" $extRestSecretName "nonExtSecretName" "pega-upgrade-rest-secret-name" "context" .root -}}
          {{ include "secretResolver" $pegaRestDict | indent 10}}

          # Fix it, Below peace of code always uses secret created from hz username & password. It cannot resolve hz external secret due to helm sub chart limitations. Modify it once hazelcast deployment is isolated.
          {{- if ( eq .root.Values.upgrade.isHazelcastClientServer "true" ) }}
          - secret:
              name: {{ include  "pega-hz-secret-name" .root}}
          {{- end }}
      - name: {{ template "pegaVolumeInstall" }}
        configMap:
          # This name will be referred in the volume mounts kind.
     {{- if or (eq $arg "install") (eq $arg "install-deploy") }}
          name: {{ template "pegaInstallConfig"}}
     {{- else }}
          name: {{ template "pegaUpgradeConfig"}}
     {{- end }}
          # Used to specify permissions on files within the volume.
          defaultMode: 420
{{ if (eq (include "customArtifactorySSLVerificationEnabled" .root) "true") }}
{{- if .root.Values.global.customArtifactory.certificate }}
{{- include "pegaCustomArtifactoryCertificateTemplate" .root | indent 6 }}
{{- end }}
{{- end }}
      initContainers:
{{- $credVolumeName := include "pegaInstallerCredentialsVolume" .root }}
{{- $artifactoryCertVolumeName := include "pegaCustomArtifactoryCertificateTemplate" .root }}
{{- include "jdbc-downloader-init-container" (merge .root (dict "credVolumeName" $credVolumeName "artifactoryCertVolumeName" $artifactoryCertVolumeName)) | indent 6 }}
{{- include "kit-downloader-init-container" (merge .root (dict "credVolumeName" $credVolumeName "artifactoryCertVolumeName" $artifactoryCertVolumeName)) | indent 6 }}
{{- range $i, $val := .initContainers }}
{{ include $val $.root | indent 6 }}
{{- end }}
{{- if .root.Values.customInitContainers }}
{{ toYaml .root.Values.customInitContainers | indent 6 }}
{{- end }}

{{- if .root.Values.nodeSelector }}
      nodeSelector:
{{ toYaml .root.Values.nodeSelector | indent 8 }}
{{- end }}
      containers:
      - name: {{ template "pegaDBInstallerContainer" }}
        image: {{ include "pegaInstallerImage" . }}
{{- if .root.Values.imagePullPolicy }}
        imagePullPolicy: {{ .root.Values.imagePullPolicy  }}
{{- end }}
        ports:
        - containerPort: 8080
{{- if .root.Values.securityContext }}
        securityContext:
{{ toYaml .root.Values.securityContext | indent 10 }}
{{- end }}
        resources:
          # CPU and Memory that the containers for {{ .name }} request
          {{- include "pegaInstallerResources" . | indent 10 }}
        volumeMounts:
{{- include "jdbcLibVolumeMount" .root | indent 8 }}
{{- if .root.Values.installerMountVolumeClaimName }}
        - name: {{ template "pegaInstallerMountVolume" }}
          mountPath: "/opt/pega/mount/installer"
{{- end }}
        # The given mountpath is mapped to volume with the specified name.  The config map files are mounted here.
        - name: {{ template "pegaVolumeInstall" }}
          mountPath: "/opt/pega/config"
        - name: {{ template "pegaInstallerCredentialsVolume" }}
          mountPath: "/opt/pega/secrets"
{{- include "kitVolumeMount" .root | indent 8 }}
{{- if .root.Values.custom }}
{{- if .root.Values.custom.volumeMounts }}
{{ toYaml .root.Values.custom.volumeMounts | indent 8 }}
{{- end }}
{{- end }}
{{ if (eq (include "customArtifactorySSLVerificationEnabled" .root) "true") }}
{{- if .root.Values.global.customArtifactory.certificate }}
        - name: {{ template "pegaVolumeCustomArtifactoryCertificate" }}
          mountPath: "/opt/pega/artifactory/cert"
{{- end }}
{{- end }}
        env:
        - name: ACTION
          value: {{ .action }}
{{- if .root.Values.custom }}
{{- if .root.Values.custom.env }}
        # Additional custom env vars
{{ toYaml .root.Values.custom.env | indent 8 }}
{{- end }}
{{- end }}
{{- if or (eq $arg "pre-upgrade") (eq $arg "post-upgrade") (eq $arg "upgrade")  }}
{{- if (eq .root.Values.upgrade.isHazelcastClientServer "true") }}
        -  name: HZ_VERSION
           valueFrom:
            configMapKeyRef:
              name: {{ template "pegaEnvironmentConfig" .root }}
              key: HZ_VERSION
        -  name: HZ_CLUSTER_NAME
           valueFrom:
            configMapKeyRef:
              name: {{ template "pegaEnvironmentConfig" .root }}
              key: HZ_CLUSTER_NAME
        -  name: HZ_SERVER_HOSTNAME
           valueFrom:
            configMapKeyRef:
              name: {{ template "pegaEnvironmentConfig" .root}}
              key: HZ_SERVER_HOSTNAME
{{- end }}
        envFrom:
        - configMapRef:
            name: {{ template "pegaUpgradeEnvironmentConfig" }}
{{- end }}
{{- if (eq $arg "install") }}
        envFrom:
        - configMapRef:
            name: {{ template "pegaInstallEnvironmentConfig" }}
{{- end }}
{{- if .root.Values.sidecarContainers }}
{{ toYaml .root.Values.sidecarContainers | indent 6 }}
{{- end }}
      restartPolicy: Never
      imagePullSecrets:
{{- include "imagePullSecrets" .root | indent 6 }}
{{- include "podAffinity" .root.Values | indent 6 }}
{{- include "tolerations" .root.Values | indent 6 }}
---
{{- end -}}